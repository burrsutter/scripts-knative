package com.redhat.developer.demos.sbeventinghello;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbeventinghelloApplicationTests {

	@Test
	void contextLoads() {
	}

}
