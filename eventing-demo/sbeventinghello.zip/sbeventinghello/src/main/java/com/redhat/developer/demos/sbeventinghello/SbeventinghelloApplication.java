package com.redhat.developer.demos.sbeventinghello;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbeventinghelloApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbeventinghelloApplication.class, args);
	}

}
